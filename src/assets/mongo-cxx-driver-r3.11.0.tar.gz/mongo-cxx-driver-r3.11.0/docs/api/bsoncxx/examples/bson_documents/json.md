# Convert to a JSON String

## From a Document

@snippet api/bsoncxx/examples/bson_documents/json/document.cpp Example

## From an Array

@snippet api/bsoncxx/examples/bson_documents/json/array.cpp Example
