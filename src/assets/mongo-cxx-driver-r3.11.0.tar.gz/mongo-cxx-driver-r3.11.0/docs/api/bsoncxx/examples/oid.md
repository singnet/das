# Basic Usage

@snippet api/bsoncxx/examples/oid/basic_usage.cpp Example

# Error Handling

@snippet api/bsoncxx/examples/oid/errors.cpp Example
